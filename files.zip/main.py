"""
main.py — DNS Injection Bypass Proxy
Entry point with CLI argument parsing.

Usage:
    sudo python main.py
    sudo python main.py --verbose
    sudo python main.py --upstream 1.1.1.1 --ttl 20 --window 3.0
    sudo python main.py --host 0.0.0.0 --port 5353
"""

import argparse
import signal
import sys
import os

from cache import HostsCache
from filter import InjectionFilter
from server import DNSProxyServer

BANNER = r"""
  ____  _   _ ____    ____
 |  _ \| \ | / ___|  |  _ \ _ __ _____  ___   _
 | | | |  \| \___ \  | |_) | '__/ _ \ \/ / | | |
 | |_| | |\  |___) | |  __/| | | (_) >  <| |_| |
 |____/|_| \_|____/  |_|   |_|  \___/_/\_\\__, |
                                            |___/
  DNS Injection Bypass Proxy — Anti-GFW Edition
"""


def parse_args():
    p = argparse.ArgumentParser(
        description="Local DNS proxy that detects and bypasses DNS injection (GFW)."
    )
    p.add_argument("--host",     default="127.0.0.1", help="Listen address (default: 127.0.0.1)")
    p.add_argument("--port",     type=int, default=5353, help="Listen port (default: 5353)")
    p.add_argument("--upstream", default="8.8.8.8",   help="Upstream DNS server (default: 8.8.8.8)")
    p.add_argument("--upstream-port", type=int, default=53, help="Upstream port (default: 53)")
    p.add_argument("--ttl",      type=int, default=10, help="Min TTL threshold — below = fake (default: 10)")
    p.add_argument("--window",   type=float, default=2.0, help="Response collection window in seconds (default: 2.0)")
    p.add_argument("--hosts-dir", default="hosts_cache", help="Folder with .txt host files (default: ./hosts_cache)")
    p.add_argument("--verbose",  action="store_true", help="Show TTL values and per-response detail")
    return p.parse_args()


def main():
    args = parse_args()

    print(BANNER)

    # Check privileges (raw socket needs root on Linux)
    if os.name != "nt" and os.geteuid() != 0:
        print("[WARN] Not running as root. Raw socket operations may fail.")
        print("[WARN] Try: sudo python main.py\n")

    # Build components
    print(f"[INIT] Loading hosts cache from: {args.hosts_dir}")
    cache = HostsCache(folder=args.hosts_dir, reload_interval=5.0)
    print(f"[INIT] Loaded {cache.size()} cached entries.\n")

    injection_filter = InjectionFilter(
        upstream=args.upstream,
        upstream_port=args.upstream_port,
        collect_window=args.window,
        min_ttl=args.ttl,
        verbose=args.verbose,
    )

    server = DNSProxyServer(
        host=args.host,
        port=args.port,
        cache=cache,
        injection_filter=injection_filter,
        verbose=args.verbose,
    )

    # Graceful shutdown
    def shutdown(sig, frame):
        print("\n[SERVER] Shutting down...")
        server.stop()
        cache.stop()
        server.print_stats()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        server.start()
    except PermissionError:
        print("[ERROR] Permission denied. Run with sudo.")
        sys.exit(1)
    except OSError as e:
        print(f"[ERROR] Could not bind to {args.host}:{args.port} — {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
