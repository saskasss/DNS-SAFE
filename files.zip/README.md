# DNS Injection Bypass Proxy

A local DNS proxy that detects and bypasses **DNS injection** (used by the GFW and similar censorship systems).

## How it works

The GFW intercepts your DNS query and **injects a fake response** before the real server can reply. The fake response usually has:
- A **much lower TTL** (e.g. TTL=1 vs TTL=300 from a real server)
- It arrives **faster** than the genuine reply

This proxy fights back by:
1. **Collecting all responses** for a configurable window (default: 2 seconds)
2. **Rejecting responses with TTL below the threshold** (default: TTL < 10)
3. **Accepting the last legitimate response** as the real answer

---

## Project Structure

```
dns_proxy/
├── main.py          ← Entry point (CLI)
├── cache.py         ← Local hosts cache with hot-reload
├── filter.py        ← DNS injection detection engine
├── server.py        ← UDP DNS proxy server
└── hosts_cache/
    └── default.txt  ← Your domain→IP mappings
```

---

## Usage

### Basic (requires sudo on Linux)
```bash
sudo python main.py
```

### Full options
```bash
sudo python main.py \
  --upstream 8.8.8.8 \   # Upstream DNS server
  --ttl 10 \             # Minimum TTL (below = fake)
  --window 2.0 \         # Response collection window (seconds)
  --hosts-dir ./hosts_cache \
  --verbose              # Show TTL details per response
```

### Point your system at this proxy
After starting, change your system DNS to:
```
127.0.0.1 port 5353
```

On Linux (temporary):
```bash
echo "nameserver 127.0.0.1" | sudo tee /etc/resolv.conf
```

---

## Hosts Cache Format

Add files ending in `.txt` to the `hosts_cache/` folder:
```
# domain       IP
google.com      142.250.185.46
youtube.com     142.250.185.14
```

Files are **auto-reloaded every 5 seconds** — no restart needed.

---

## Output Legend

| Tag | Meaning |
|-----|---------|
| `[CACHE HIT]` | Resolved from local hosts file |
| `[ACCEPTED]` | Real response passed TTL filter |
| `[BLOCKED]` | Fake response (TTL too low) — dropped |
| `[FAILED]` | All responses were fake / no reply |

---

## Tuning Tips

- **TTL too aggressive?** Lower `--ttl` to 5 if too many real responses are being blocked
- **Missing responses?** Increase `--window` to 3.0 or 4.0 on slow connections
- **Upstream blocked?** Try `--upstream 1.1.1.1` (Cloudflare) or `--upstream 9.9.9.9` (Quad9)

---

## Requirements

```bash
pip install dnslib
# scapy is optional — the filter uses raw sockets directly
```

Python 3.9+ recommended.
