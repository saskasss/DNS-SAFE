"""
cache.py — Local DNS Hosts Cache
Reads domain→IP mappings from .txt files in a folder.
Supports hot-reload when files change.
"""

import os
import time
import threading
from typing import Optional


class HostsCache:
    """
    Watches a folder of .txt files with lines like:
        google.com  142.250.185.46
        # comments are ignored
    """

    def __init__(self, folder: str, reload_interval: float = 5.0):
        self.folder = folder
        self.reload_interval = reload_interval
        self._cache: dict[str, str] = {}
        self._mtimes: dict[str, float] = {}
        self._lock = threading.RLock()
        self._stop_event = threading.Event()

        # Initial load
        self._load_all()

        # Start background watcher
        self._watcher = threading.Thread(target=self._watch_loop, daemon=True)
        self._watcher.start()

    def resolve(self, domain: str) -> Optional[str]:
        """Return cached IP for domain, or None if not found."""
        domain = domain.rstrip(".")  # strip trailing dot (FQDN)
        with self._lock:
            return self._cache.get(domain) or self._cache.get(f"www.{domain}")

    def size(self) -> int:
        with self._lock:
            return len(self._cache)

    def stop(self):
        self._stop_event.set()

    # ── Internal ────────────────────────────────────────────────────────────

    def _load_all(self):
        if not os.path.isdir(self.folder):
            os.makedirs(self.folder, exist_ok=True)
            return

        new_cache: dict[str, str] = {}
        new_mtimes: dict[str, float] = {}

        for fname in os.listdir(self.folder):
            if not fname.endswith(".txt"):
                continue
            fpath = os.path.join(self.folder, fname)
            mtime = os.path.getmtime(fpath)
            new_mtimes[fpath] = mtime
            self._parse_file(fpath, new_cache)

        with self._lock:
            self._cache = new_cache
            self._mtimes = new_mtimes

    def _parse_file(self, path: str, target: dict):
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        domain, ip = parts[0].lower(), parts[1]
                        target[domain] = ip
        except Exception as e:
            print(f"[CACHE] Error reading {path}: {e}")

    def _watch_loop(self):
        while not self._stop_event.wait(self.reload_interval):
            self._check_and_reload()

    def _check_and_reload(self):
        if not os.path.isdir(self.folder):
            return
        changed = False
        current_files = set()

        for fname in os.listdir(self.folder):
            if not fname.endswith(".txt"):
                continue
            fpath = os.path.join(self.folder, fname)
            current_files.add(fpath)
            mtime = os.path.getmtime(fpath)
            if self._mtimes.get(fpath) != mtime:
                changed = True
                break

        # Also check for deleted files
        if set(self._mtimes.keys()) != current_files:
            changed = True

        if changed:
            print("[CACHE] Change detected — reloading hosts files...")
            self._load_all()
            print(f"[CACHE] Loaded {self.size()} entries.")
