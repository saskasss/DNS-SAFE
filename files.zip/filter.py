"""
filter.py — DNS Injection Filter
Sends a raw DNS query and collects ALL responses for a window of time.
Rejects responses whose TTL is suspiciously low (GFW-injected fakes).
Accepts the last remaining response as the legitimate one.
"""

import socket
import struct
import time
import threading
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DNSResponse:
    ip: str
    ttl: int
    arrived_at: float = field(default_factory=time.time)
    is_fake: bool = False


class InjectionFilter:
    """
    Detects GFW-style DNS injection by:
    1. Collecting all UDP responses in a time window
    2. Flagging responses with TTL < min_ttl as injected fakes
    3. Returning the last response that passes the TTL check
    """

    def __init__(
        self,
        upstream: str = "8.8.8.8",
        upstream_port: int = 53,
        collect_window: float = 2.0,   # seconds to collect responses
        min_ttl: int = 10,             # TTL below this → fake
        verbose: bool = False,
    ):
        self.upstream = upstream
        self.upstream_port = upstream_port
        self.collect_window = collect_window
        self.min_ttl = min_ttl
        self.verbose = verbose

    def query(self, domain: str) -> Optional[DNSResponse]:
        """
        Send a DNS A-record query for `domain` and return the best response,
        or None if all responses are fake / no response received.
        """
        raw_query = self._build_query(domain)
        responses: list[DNSResponse] = []
        stop = threading.Event()

        # Send query
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self.collect_window + 0.5)
        try:
            sock.sendto(raw_query, (self.upstream, self.upstream_port))

            deadline = time.time() + self.collect_window
            while True:
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                sock.settimeout(remaining)
                try:
                    data, _ = sock.recvfrom(512)
                    resp = self._parse_response(data)
                    if resp:
                        resp.is_fake = resp.ttl < self.min_ttl
                        responses.append(resp)
                        if self.verbose:
                            tag = "[BLOCKED]" if resp.is_fake else "[CANDIDATE]"
                            print(f"  {tag} ip={resp.ip} ttl={resp.ttl}")
                except socket.timeout:
                    break
                except Exception as e:
                    if self.verbose:
                        print(f"  [FILTER] recv error: {e}")
                    break
        finally:
            sock.close()

        return self._pick_best(responses)

    # ── Picking logic ────────────────────────────────────────────────────────

    def _pick_best(self, responses: list[DNSResponse]) -> Optional[DNSResponse]:
        genuine = [r for r in responses if not r.is_fake]
        if genuine:
            # Pick the last genuine response (real server tends to arrive later)
            best = genuine[-1]
            return best
        # All responses were fake — return None
        return None

    # ── DNS packet builder ───────────────────────────────────────────────────

    def _build_query(self, domain: str) -> bytes:
        """Build a minimal DNS A-record query packet."""
        transaction_id = 0x1234
        flags = 0x0100          # Standard query, recursion desired
        qdcount = 1
        header = struct.pack(">HHHHHH", transaction_id, flags, qdcount, 0, 0, 0)

        # Encode QNAME
        qname = b""
        for label in domain.rstrip(".").split("."):
            encoded = label.encode()
            qname += bytes([len(encoded)]) + encoded
        qname += b"\x00"

        qtype = 1    # A record
        qclass = 1   # IN
        question = qname + struct.pack(">HH", qtype, qclass)
        return header + question

    # ── DNS response parser ──────────────────────────────────────────────────

    def _parse_response(self, data: bytes) -> Optional[DNSResponse]:
        """
        Minimal parser: extract first A-record answer's IP and TTL.
        """
        try:
            if len(data) < 12:
                return None

            # Header
            flags = struct.unpack(">H", data[2:4])[0]
            qr = (flags >> 15) & 1
            if qr != 1:   # Not a response
                return None

            ancount = struct.unpack(">H", data[6:8])[0]
            if ancount == 0:
                return None

            # Skip question section
            offset = 12
            while offset < len(data) and data[offset] != 0:
                offset += data[offset] + 1
            offset += 5  # null byte + qtype + qclass

            # Parse first answer
            offset = self._skip_name(data, offset)
            if offset + 10 > len(data):
                return None

            rtype, rclass, ttl, rdlength = struct.unpack(">HHIH", data[offset:offset+10])
            offset += 10

            if rtype == 1 and rdlength == 4:  # A record
                ip = ".".join(str(b) for b in data[offset:offset+4])
                return DNSResponse(ip=ip, ttl=ttl)

            return None
        except Exception:
            return None

    def _skip_name(self, data: bytes, offset: int) -> int:
        """Skip a DNS name (handles compression pointers)."""
        while offset < len(data):
            length = data[offset]
            if length == 0:
                return offset + 1
            if (length & 0xC0) == 0xC0:   # Pointer
                return offset + 2
            offset += length + 1
        return offset
