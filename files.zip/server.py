"""
server.py — Local DNS Proxy Server
Listens on 127.0.0.1:5353 (UDP).
Resolution order:
  1. Local hosts cache  → instant reply
  2. InjectionFilter    → upstream query with fake-response filtering
"""

import socket
import struct
import threading
import time
from typing import Optional

from cache import HostsCache
from filter import InjectionFilter, DNSResponse


class DNSProxyServer:
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 5353,
        cache: HostsCache = None,
        injection_filter: InjectionFilter = None,
        verbose: bool = False,
    ):
        self.host = host
        self.port = port
        self.cache = cache
        self.filter = injection_filter
        self.verbose = verbose
        self._sock: Optional[socket.socket] = None
        self._running = False
        self._stats = {"cache_hits": 0, "accepted": 0, "blocked": 0, "failed": 0}

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._running = True
        print(f"[SERVER] DNS proxy listening on {self.host}:{self.port}")
        print(f"[SERVER] Upstream: {self.filter.upstream}:{self.filter.upstream_port}")
        print(f"[SERVER] TTL threshold: {self.filter.min_ttl}  |  Collect window: {self.filter.collect_window}s\n")

        try:
            while self._running:
                try:
                    self._sock.settimeout(1.0)
                    data, addr = self._sock.recvfrom(512)
                    t = threading.Thread(
                        target=self._handle, args=(data, addr), daemon=True
                    )
                    t.start()
                except socket.timeout:
                    continue
        finally:
            self._sock.close()

    def stop(self):
        self._running = False

    def print_stats(self):
        s = self._stats
        total = s["cache_hits"] + s["accepted"] + s["blocked"] + s["failed"]
        print(
            f"\n[STATS] Total queries: {total} | "
            f"Cache hits: {s['cache_hits']} | "
            f"Accepted: {s['accepted']} | "
            f"Blocked/fake: {s['blocked']} | "
            f"Failed: {s['failed']}"
        )

    # ── Handler ──────────────────────────────────────────────────────────────

    def _handle(self, data: bytes, addr):
        domain = self._extract_query_domain(data)
        if not domain:
            return

        # 1. Check local cache first
        cached_ip = self.cache.resolve(domain) if self.cache else None
        if cached_ip:
            self._stats["cache_hits"] += 1
            print(f"[CACHE HIT]  {domain} → {cached_ip}")
            reply = self._build_reply(data, cached_ip, ttl=300)
            self._sock.sendto(reply, addr)
            return

        # 2. Query upstream with injection filter
        if self.verbose:
            print(f"[QUERY]      {domain} → querying upstream...")

        t0 = time.time()
        result: Optional[DNSResponse] = self.filter.query(domain)
        elapsed = time.time() - t0

        if result:
            self._stats["accepted"] += 1
            ttl_info = f"ttl={result.ttl}" if self.verbose else ""
            print(f"[ACCEPTED]   {domain} → {result.ip}  {ttl_info}  ({elapsed:.2f}s)")
            reply = self._build_reply(data, result.ip, ttl=result.ttl)
            self._sock.sendto(reply, addr)
        else:
            self._stats["failed"] += 1
            print(f"[FAILED]     {domain} — all responses were fake or no reply")
            # Send NXDOMAIN
            reply = self._build_nxdomain(data)
            self._sock.sendto(reply, addr)

    # ── DNS packet helpers ───────────────────────────────────────────────────

    def _extract_query_domain(self, data: bytes) -> Optional[str]:
        try:
            offset = 12
            labels = []
            while offset < len(data) and data[offset] != 0:
                length = data[offset]
                labels.append(data[offset+1:offset+1+length].decode())
                offset += length + 1
            return ".".join(labels).lower()
        except Exception:
            return None

    def _build_reply(self, query: bytes, ip: str, ttl: int = 60) -> bytes:
        """Craft a DNS A-record response packet."""
        tid = query[:2]
        flags = b"\x81\x80"     # Response, no error
        counts = struct.pack(">HHHH", 1, 1, 0, 0)

        # Copy question section
        q_end = 12
        while q_end < len(query) and query[q_end] != 0:
            q_end += query[q_end] + 1
        q_end += 5  # null + qtype + qclass
        question = query[12:q_end]

        # Answer RR
        name_ptr = b"\xc0\x0c"  # pointer to offset 12 (domain name in question)
        rtype = struct.pack(">H", 1)    # A
        rclass = struct.pack(">H", 1)   # IN
        rttl = struct.pack(">I", max(ttl, 1))
        rdata = bytes(map(int, ip.split(".")))
        rdlength = struct.pack(">H", 4)
        answer = name_ptr + rtype + rclass + rttl + rdlength + rdata

        return tid + flags + counts + question + answer

    def _build_nxdomain(self, query: bytes) -> bytes:
        tid = query[:2]
        flags = b"\x81\x83"  # Response, NXDOMAIN
        counts = struct.pack(">HHHH", 1, 0, 0, 0)
        q_end = 12
        while q_end < len(query) and query[q_end] != 0:
            q_end += query[q_end] + 1
        q_end += 5
        question = query[12:q_end]
        return tid + flags + counts + question
